/**
 * Author: Tapan Nayak
 * Assignment 2 - Fall. 2020
 * Purpose : To extend the abstract class and override all essential methods on ad-hoc basis
 */
package cst8218.naya0007.entity;

import cst8218.naya0007.entity.Sprite;
import cst8218.naya0007.game.AbstractFacade;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author tgk
 */
@Stateless
public class SpriteFacade extends AbstractFacade<Sprite> {
    @PersistenceContext(unitName = "SpriteTapan-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SpriteFacade() {
        super(Sprite.class);
    }
    
}
