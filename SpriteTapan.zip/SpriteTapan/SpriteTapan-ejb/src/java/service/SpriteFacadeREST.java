/**
 * Author: Tapan Nayak
 * Assignment 1 - Fall. 2020
 * Purpose: To implement REST API by extending the AbstractFacade<sprite> (via CRUD)
 */
package service;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import cst8218.naya0007.game.AbstractFacade;
import cst8218.naya0007.entity.Sprite;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.RolesAllowed;
/**
 *
 * @author tnayak
 */
@Stateless
@DeclareRoles({"Admin","RestGroup"})
@RolesAllowed({"Admin","RestGroup"})
@Path("cst8218.naya0007.game.sprite")
public class SpriteFacadeREST extends AbstractFacade<Sprite> {

    @PersistenceContext(unitName = "SpriteTapan-ejbPU")
    private EntityManager em;

    public SpriteFacadeREST() {
        super(Sprite.class);
    }

    // POST/: to create record in database
    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Sprite entity) {
        super.create(entity);
    }

    // PUT/(id)/ : find a record by id and edit it in database via REST call
    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Long id, Sprite entity) {
        super.edit(entity);
    }

    // DELETE/{id}/ : find record by id and delete it in database via REST call
    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Long id) {
        super.remove(super.find(id));
    }

    // GET/{id}/ : get record by id 
    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Sprite find(@PathParam("id") Long id) {
        return super.find(id);
    }

    // GET/ : get all record from databsae
    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Sprite> findAll() {
        return super.findAll();
    }

    // GET/{from}/{to}/ : get all record in a range from database
    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Sprite> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    // GET/count : get total number of records from database 
    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    // get EntityManager
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
}
