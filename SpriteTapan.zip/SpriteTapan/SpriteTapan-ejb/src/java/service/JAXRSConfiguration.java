/*
 * CST8218 Assignment 2
 */
package service;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;


@ApplicationPath("resources")
public class JAXRSConfiguration extends Application {
    
}
